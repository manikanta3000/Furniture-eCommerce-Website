module.export = {
  plugin: [require("prettier-plugin-tailwindcss")],
};
