const SharedTitle = () => {
  return (
    <div className="flex">
      <h1 className="md:text-md font-jose text-sm font-semibold text-blue">
        Ecommerce Accessories & Fashion item
      </h1>
    </div>
  );
};

export default SharedTitle;
