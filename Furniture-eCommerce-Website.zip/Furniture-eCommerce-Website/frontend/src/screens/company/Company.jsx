import AboutUs from "./AboutUs";
import Contact from "./Contact";

const Company = () => {
  return (
    <>
      <AboutUs />
      <Contact />
    </>
  );
};

export default Company;
