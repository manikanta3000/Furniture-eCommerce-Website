const allowedOrigins = ["https://frontend-furniture.firebaseapp.com/"];

export { allowedOrigins };
